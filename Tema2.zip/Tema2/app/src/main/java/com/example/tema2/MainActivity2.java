package com.example.tema2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity2 extends AppCompatActivity {

    private ArrayList<Student> usersList;
    private RecyclerView recyclerViewMain;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        recyclerViewMain = findViewById(R.id.recyclerViewMain);
        usersList = new ArrayList<>();
        setUserInfo();
        setAdapter();
    }

    private void setAdapter() {
        recyclerAdapter adapter = new recyclerAdapter(usersList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerViewMain.setLayoutManager(layoutManager);
        recyclerViewMain.setItemAnimator(new DefaultItemAnimator());
        recyclerViewMain.setAdapter(adapter);
    }

    private void setUserInfo(){


        String names[] = {"Babiciu Andreea", "Buciuman Daria", "Colceriu Cristian", "Costin Radu",
                "Farcasanu Melisa", "Fat Nicolae", "Faur Edward", "Hosu Anamaria",
                "Ilies Alexandru", "Mali Attilla", "Manu Alexandru", "Maries Monica", "Nechita Razvan",
                "Nechita Nadia", "Oana Rares", "Pasca Gabriela", "Patacean Maria", "Pop Raul",
                "Ratiu David", "Stan Sergiu", "Stan Yonash", "Tartia Alex", "Tatar Andreea", "Ungur David",
                "Viman Paul"};
        for (int i = 0; i<25;i++){
            usersList.add(new Student(names[i]));
        } //end for
    }//setUserInfo

    public void Back(View view){
        Intent intent_2 = new Intent(this, MainActivity.class);
        startActivity(intent_2);
    }
}